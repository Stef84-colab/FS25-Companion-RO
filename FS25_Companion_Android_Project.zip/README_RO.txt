FS25 COMPANION RO - PROIECT ANDROID
===================================

Acesta este un proiect Android real. Aplicația funcționează OFFLINE și își deschide
ghidul FS25 direct, fără browser.

CEA MAI UȘOARĂ METODĂ PENTRU APK, FĂRĂ ANDROID STUDIO:
1. Creezi un repository NOU pe GitHub.
2. Încarci TOATE fișierele și folderele din acest proiect în repository.
3. GitHub Actions pornește automat workflow-ul "Build FS25 Android APK".
4. Intri în tab-ul Actions -> ultima rulare terminată cu verde.
5. Jos, la Artifacts, descarci "FS25-Companion-RO-APK".
6. Dezarhivezi artifact-ul și vei avea app-debug.apk.
7. Trimiți APK-ul pe telefon și îl instalezi.
   Android poate cere permisiunea "Install unknown apps" pentru browser/file manager.

DUPĂ INSTALARE:
- apare în telefon ca "FS25 Companion RO"
- are iconiță proprie
- se deschide separat, ca aplicație
- funcționează offline

IMPORTANT:
app-debug.apk este o aplicație Android reală, dar este semnată cu cheia debug generată
de sistemul de build. Este perfectă pentru instalare personală pe telefon.
