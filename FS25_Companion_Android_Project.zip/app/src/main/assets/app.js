
(() => {
  const D = window.FS25_DATA;
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const animalGrid = $("#animalGrid"), foodGrid = $("#foodGrid"), cropList = $("#cropList");
  $("#animalCount").textContent = D.animals.length;

  const diffClass = d => /ridicat/i.test(d) ? "hard" : /mediu/i.test(d) ? "warn" : "good";

  function renderAnimals(filter=""){
    const q = filter.trim().toLowerCase();
    animalGrid.innerHTML = "";
    D.animals.filter(a => a.name.toLowerCase().includes(q)).forEach(a => {
      const el = document.createElement("button");
      el.type="button"; el.className="card clickable"; el.dataset.animal=a.id;
      el.innerHTML = `
        <div class="card-top">
          <div class="animal-name"><span class="animal-emoji">${a.emoji}</span><div><h4>${a.name}</h4><span class="small muted">${a.products}</span></div></div>
          <span class="tag ${diffClass(a.difficulty)}">${a.difficulty}</span>
        </div>
        <p class="card-desc"><b>Recomandat:</b> ${a.best}<br><b>Pentru început:</b> ${a.starter}</p>
        <div class="food-preview">${a.foods.slice(0,4).map(f=>`<span class="food-pill">${f.name}</span>`).join("")}</div>
        <span class="open-hint">Vezi hrană + strategie →</span>`;
      animalGrid.appendChild(el);
    });
  }

  function renderFoods(){
    foodGrid.innerHTML="";
    D.foods.forEach(f=>{
      const el=document.createElement("button");
      el.type="button";el.className="card clickable";el.dataset.food=f.id;
      el.innerHTML=`<div class="food-card-title"><span>${f.emoji}</span><div><h4>${f.name}</h4><p>${f.usedBy}</p></div></div>
      <p class="card-desc">${f.tip}</p>
      <div class="food-preview"><span class="tag good">${f.profit}</span><span class="tag ${diffClass(f.complexity)}">${f.complexity}</span></div>
      <span class="open-hint">Vezi pașii + utilajele →</span>`;
      foodGrid.appendChild(el);
    })
  }

  function renderCrops(filter=""){
    const q=filter.trim().toLowerCase(); cropList.innerHTML="";
    D.crops.filter(c=>(c.name+" "+c.uses).toLowerCase().includes(q)).forEach(c=>{
      const el=document.createElement("article");el.className="crop-row";
      el.innerHTML=`<h4>🌾 ${c.name}</h4><p><b>Util pentru:</b> ${c.uses}</p><p><b>Flux:</b> ${c.flow}</p>`;
      cropList.appendChild(el);
    })
  }

  function openAnimal(id){
    const a=D.animals.find(x=>x.id===id); if(!a)return;
    $("#modalContent").innerHTML=`
      <div class="detail-title"><span class="big">${a.emoji}</span><div><h2 id="modalTitle">${a.name}</h2><div class="food-preview"><span class="tag ${diffClass(a.difficulty)}">${a.difficulty}</span><span class="tag good">Profit: ${a.profit}</span></div></div></div>
      <div class="detail-section"><h3>Ce produce</h3><p class="muted">${a.products}</p></div>
      <div class="detail-section"><h3>Ce mănâncă</h3>${a.foods.map(f=>`
        <div class="food-row"><div class="food-row-head"><b>${f.name}</b><span>${f.prod}</span></div><div class="small muted">${f.why}</div>
        ${typeof f.score==="number" ? `<div class="bar"><i style="width:${Math.max(5,Math.min(100,f.score))}%"></i></div>`:""}</div>`).join("")}</div>
      <div class="detail-section"><h3>Recomandarea aplicației</h3><div class="panel"><b>🏆 Maxim:</b> ${a.best}<br><b>🌱 Începător:</b> ${a.starter}<p class="muted">${a.notes}</p></div></div>
      <button type="button" class="primary go-plan" data-plan="${a.id}">Fă-mi planul complet</button>`;
    showModal();
    $(".go-plan").addEventListener("click",()=>{ closeModal(); switchView("planner"); $("#plannerAnimal").value=a.id; buildPlan(); });
  }

  function openFood(id){
    const f=D.foods.find(x=>x.id===id); if(!f)return;
    $("#modalContent").innerHTML=`
      <div class="detail-title"><span class="big">${f.emoji}</span><div><h2 id="modalTitle">${f.name}</h2><div class="food-preview"><span class="tag good">${f.profit}</span><span class="tag ${diffClass(f.complexity)}">${f.complexity}</span></div></div></div>
      <div class="detail-section"><h3>Folosită de</h3><p class="muted">${f.usedBy}</p></div>
      <div class="detail-section"><h3>Pașii de producție</h3>${f.steps.map((s,i)=>`<div class="step"><span class="step-num">${i+1}</span><div>${s}</div></div>`).join("")}</div>
      <div class="detail-section"><h3>Utilaje necesare</h3><div class="machine-list">${f.machines.map(m=>`<span class="machine">🚜 ${m}</span>`).join("")}</div></div>
      <div class="detail-section"><div class="panel"><b>💡 Sfat:</b> ${f.tip}</div></div>`;
    showModal();
  }

  function showModal(){ const m=$("#modal");m.hidden=false;document.body.style.overflow="hidden";$("#modalClose").focus(); }
  function closeModal(){ $("#modal").hidden=true;document.body.style.overflow=""; }

  function switchView(name){
    $$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
    $$(".view").forEach(v=>v.classList.toggle("active",v.id===name+"View"));
    window.scrollTo({top:0,behavior:"smooth"});
  }

  $$(".tab").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
  animalGrid.addEventListener("click",e=>{const b=e.target.closest("[data-animal]");if(b)openAnimal(b.dataset.animal)});
  foodGrid.addEventListener("click",e=>{const b=e.target.closest("[data-food]");if(b)openFood(b.dataset.food)});
  $("#modalClose").addEventListener("click",closeModal);
  $("#modal").addEventListener("click",e=>{if(e.target.dataset.close)closeModal()});
  document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!$("#modal").hidden)closeModal()});
  $("#animalSearch").addEventListener("input",e=>renderAnimals(e.target.value));
  $("#cropSearch").addEventListener("input",e=>renderCrops(e.target.value));

  const pa=$("#plannerAnimal");
  D.animals.filter(a=>a.id!=="bees").forEach(a=>{const o=document.createElement("option");o.value=a.id;o.textContent=a.emoji+" "+a.name;pa.appendChild(o)});
  $("#buildPlan").addEventListener("click",buildPlan);

  function chooseFoodForAnimal(a, strategy){
    if(a.id==="cows"||a.id==="buffalo") return strategy==="best" ? "tmr" : "hay";
    if(a.id==="pigs") return "pigmix";
    if(a.id==="sheep"||a.id==="goats") return strategy==="best" ? "hay" : "grass";
    if(a.id==="chickens") return "grain";
    if(a.id==="horses") return "hay";
    return null;
  }

  function buildPlan(){
    const a=D.animals.find(x=>x.id===pa.value); const strategy=$("#plannerStrategy").value;
    const foodId=chooseFoodForAnimal(a,strategy); const f=D.foods.find(x=>x.id===foodId);
    let extra="";
    if(a.id==="horses") extra=`<div class="panel" style="margin-top:10px"><b>+ Ovăz:</b> cultivă ovăz cu semănătoare și combină; pentru cai urmărește și antrenarea/îngrijirea.</div>`;
    $("#planResult").innerHTML=`
      <h3>${a.emoji} Plan pentru ${a.name}</h3>
      <p><b>Țintă:</b> ${strategy==="best"?"productivitate maximă":"setup simplu pentru început"}<br><b>Hrana aleasă:</b> ${f?f.name:a.starter}</p>
      ${f?`<h4>Ce faci</h4>${f.steps.map((s,i)=>`<div class="step"><span class="step-num">${i+1}</span><div>${s}</div></div>`).join("")}
      <h4>Ce trebuie să cumperi / ai</h4><div class="machine-list">${f.machines.map(m=>`<span class="machine">${m}</span>`).join("")}</div>`:""}
      ${extra}
      <div class="panel" style="margin-top:14px"><b>💰 Eficiență:</b> ${a.notes}</div>`;
  }

  const quick={
    straw:"<b>Paiele:</b> la grâu/orz/ovăz lasă combina să facă brazdă de paie. Apoi treci cu <b>presa de balotat</b> direct peste ele. Windrower-ul doar le adună în rând; nu face baloți.",
    lime:"<b>Var:</b> dacă harta spune că terenul are nevoie de var, îl poți aplica. După aceea continui cu pregătirea solului / semănatul. Nu trebuie să sapi doar ca să poți da var.",
    chicken:"<b>Găini:</b> folosește grâu, orz sau sorg. Cel mai sigur: pune cerealele într-o remorcă și descarcă exact în triggerul de hrană al cotețului. Dacă ai un BigBag/palet pe jos, mutarea lui este mai incomodă.",
    hay:"<b>Fân:</b> cositoare → <b>tedder</b> (obligatoriu ca iarba să devină fân) → opțional windrower → presă de balotat sau remorcă de furaje.",
    silage:"<b>Siloz simplu:</b> cosește iarba → balotează → înfoliază baloții → lasă-i să fermenteze. Este mai simplu pentru o fermă mică decât bunker-ul.",
    field:"<b>După recoltare:</b> verifică starea câmpului. Var dacă cere → arat doar dacă cere → cultivat sau semănătoare directă → semănat → cilindru opțional → fertilizare / buruieni."
  };
  $$(".quick-card").forEach(b=>b.addEventListener("click",()=>$("#quickAnswer").innerHTML=quick[b.dataset.q]));

  renderAnimals(); renderFoods(); renderCrops(); buildPlan();

  // PWA install
  let deferredPrompt;
  const ib=$("#installBtn");
  window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;ib.hidden=false});
  ib.addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;ib.hidden=true});
  if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
})();
